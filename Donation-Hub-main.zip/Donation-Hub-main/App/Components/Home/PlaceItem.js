import { View, Text } from 'react-native'
import React from 'react'

export default function PlaceItem() {
  return (
    <View>
      <Text>PlaceItem</Text>
    </View>
  )
}