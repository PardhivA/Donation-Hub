import { View, Text } from 'react-native'
import React from 'react'
import { useEffect } from 'react';
import {useNavigation} from '@react-navigation/native'


import { NativeModules } from 'react-native';


// Call this function to disable the back swipe gesture

export default function DashBoard() {
  
  return (
    <View>
      <Text>kjh</Text>
    </View>
  )
}