import { View, Text } from 'react-native'
import React from 'react'
import {createStackNavigator} from '@react-navigation/stack';
import DTabNavigation from './DTabNavigation';

const Stack = createStackNavigator();


export default function Donar() {
  return (
    <View>
        
          <Text> OM </Text>
       
    </View>
  )
}