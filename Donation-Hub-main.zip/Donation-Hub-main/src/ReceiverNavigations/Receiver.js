import { View, Text } from 'react-native'
import React from 'react'

export default function Receiver() {
  return (
    <View>
      <Text>Receiver</Text>
    </View>
  )
}